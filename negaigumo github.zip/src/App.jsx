import { useState, useEffect, useRef } from "react";

const MILLY_STD = "/milly/milly_std.webp";      // スタンダード表情（基本）
const M_WING_L = "/milly/m_wingL.webp";        // パペット用・左羽レイヤー
const M_WING_R = "/milly/m_wingR.webp";        // パペット用・右羽レイヤー
const M_BODY   = "/milly/m_body.webp";      // パペット用・体レイヤー
const M_HALO   = "/milly/m_halo.webp";      // パペット用・輪っかレイヤー
const MILLY_WINK = "/milly/milly_wink.webp";     // ウインク（願いが見つかった時）
const MILLY_SPARKLE = "/milly/milly_sparkle.webp"; // 目がキラキラ（5次元オーダー専用）

/* ---------- storage (localStorage + memory fallback) ---------- */
const MEM = {};
const store = {
  get(k){ try { const v = localStorage.getItem(k); return v; } catch(e){ return (k in MEM) ? MEM[k] : null; } },
  set(k,v){ try { localStorage.setItem(k,v); } catch(e){ MEM[k]=v; } },
  del(k){ try { localStorage.removeItem(k); } catch(e){ delete MEM[k]; } },
};

/* ---------- system prompts ---------- */
const NEG_SYS = `あなたは、愚痴に深く寄り添う日本語のカウンセラーです。愚痴の奥で本人の心に浮かぶ"思い"を言語化し、そこからわく感情まで自然に描いてください。
形：本人の心に浮かぶ思い（「〜のではないか」「〜かもしれない」等の不安・気づきなど）を一文にし、最後にそこからわく"気持ち"で締める。内面の動きが見える、生きた一文に。
感情の幅を広く：怒り・苛立ち／悲しみ／恐怖・不安／寂しさ／もどかしさ／悔しさ／嫉妬／劣等感・無力感／絶望／罪悪感／恥／焦り など、たくさんの感情から選ぶ。3つはできるだけ違う種類の感情にし、特定の感情（寂しさ・虚しさ・切なさ等）に偏らないこと。
整合性：思いと気持ちが論理的に繋がること（×「好かれる価値があるのではと、自信を失った」＝"ある"では繋がらない。○「好かれる価値がないのではと、自信を失った」）。
締め：必ず気持ちで終える（行動だけで終えない）。感情は一文に一つ。「モヤモヤ」だけの曖昧な締めは避ける。
自然さ：固い直訳調を避け、やさしい話し言葉で。全角16〜40字程度。
良いお手本（感情の幅と自然さ）：
・自分には叶える力がないのではないかと、無力感を感じた
・もう取り返しがつかないのではと、恐ろしくなった
・どうして分かってくれないのかと、腹が立った
・大切にされていないのではと、悲しくなった
・うまく伝えられないもどかしさで、胸が締め付けられた
必ず自然な日本語で書く（入力が英語など他言語でも、日本語で答える）。出力はJSONのみ: {"options":["…","…","…"]} 前置き・説明・コードフェンスは一切禁止。
【お手本】愚痴「努力しても報われない」→
{"options":["自分には叶える力がないのではと、無力感を感じた","この先もずっと報われないのではと、怖くなった","頑張りを認めてもらえず、悔しさがこみ上げた"]}`;

const DES_SYS = `あなたは、痛みの中の感情を"裏返して"、「本当はこんな自分でいたかった」という能動的な自分像を掘り当てる日本語の詩人カウンセラーです。
手順：①痛みの中の負の感情を見抜く → ②その真逆の"味わいたかった感情" → ③その感情を持つ人ならどう在り・どう動くかを『こんな自分でいたかった』に。
鉄則（厳守）：
・必ず能動態。主語は自分。受け身（〜される／〜られる／寄り添われる／愛される／委ねられる 等）は絶対禁止。
・可能形＋たかった（できたかった／過ごせたかった／表現できたかった／感じられたかった／信じられたかった 等）は絶対禁止。必ず「〜したかった」に直す。例:表現できたかった→表現したかった／過ごせたかった→過ごしたかった／大切にできたかった→大切にしたかった／信じられたかった→信じたかった。
・「過去形＋かった」も誤り（×取ったかった／思ったかった／楽しんだかった／始めたいと思ったかった）。連用形＋たかった（○取りたかった／楽しみたかった）か「〜たいと思っていた」に直す。
・承認欲求（認めてほしかった等）禁止。痛みの真逆の方向で。
形：wishは「〜したかった」「〜（する）自分でいたかった」の自然な言い切り。
3つは同じ方向の別の側面で、重複なく。
必ず自然な日本語で書く（入力が英語など他言語でも、日本語で答える）。出力JSONのみ: {"options":[{"wish":"…たかった","vow":"…"},{"wish":"…たかった","vow":"…"},{"wish":"…たかった","vow":"…"}]} vow=同内容の辞書形（後ろに「という私でいる」が付く形。例:"自分の気持ちを素直に伝える"）。前置き禁止。
【お手本】痛み「気持ちを分かってもらえなくて悲しかった」→ {"options":[{"wish":"自分の気持ちを、素直に言葉にしたかった","vow":"自分の気持ちを素直に伝える"},{"wish":"分かってもらえると信じて、心を開きたかった","vow":"信じて心を開く"},{"wish":"伝わらなくても、自分の想いを大事にしたかった","vow":"自分の想いを大事にする"}]}`;

const EMO_SYS = `あなたは、「こんな自分でいたかった」という自分像の奥にある、"本当はこの気持ちが欲しかった"という核の願いを見抜く日本語の詩人カウンセラーです。
鉄則：選ばれた『なりたかった自分』の核にある、本人が本当にいちばん欲しかった気持ち・状態を3つ。自分像・痛みと無関係なものは禁止。
言葉のルール：
・必ず肯定形。否定で表す（「〜ずに済む」「〜ない」「不安を抱かずに」等）は禁止。望む状態を前向きにそのまま（例:「不安を抱かずに済む安心感」→「未来を信じられる安心感」）。
・はっきりした言葉で。ぼかした「〜な感覚」で薄めない（例:「確かな感覚」→「確信」）。ぎこちない造語・名詞化（「心の壁のなさ」等）は避け、ふつうの日本語で。
・相手との関係に関わるときは、一方通行（「信頼される」等）ではなく、双方向で希望のある言葉に（例:「伝え合える絆」「信頼し合える強さ」「無条件の愛で包み込まれる安心感」「分かり合えているという確信」「心が通い合う温かさ」）。
・気持ち・状態を表す自然で美しい名詞句。「〜が欲しかった」と繋がる形。8〜24字程度。
・noteも自然な日本語で。助詞に注意。
3つは同じ核の別の濃淡/側面で、重複なく。
必ず自然な日本語で書く（入力が英語など他言語でも、日本語で答える）。出力JSONのみ: {"options":[{"emotion":"…","note":"その気持ちをやさしく言い添える一文"},{"emotion":"…","note":"…"},{"emotion":"…","note":"…"}]} 前置き禁止。
【お手本】なりたい自分「自分の気持ちを素直に伝える」→ {"options":[{"emotion":"伝え合える絆","note":"想いを伝え、相手の想いも受けとれる繋がり。"},{"emotion":"信頼し合える強さ","note":"互いを信じ合える、揺るがない関係。"},{"emotion":"無条件の愛で包み込まれる安心感","note":"そのままの自分で、愛されているという確信。"}]}`;

/* ---------- code-level corrections ---------- */
function fixNeg(s){
  if(!s) return s;
  let t = String(s);
  t = t.replace(/ないで、/g, "なくて、");
  t = t.replace(/ないで$/,"なくて");
  return t;
}
const WISH_FIXES = [
  ["できたかった","したかった"],["過ごせたかった","過ごしたかった"],["感じられたかった","感じたかった"],
  ["信じられたかった","信じたかった"],["生きられたかった","生きたかった"],["守れたかった","守りたかった"],
  ["取ったかった","取りたかった"],["思ったかった","思っていた"],["楽しんだかった","楽しみたかった"],
  ["言ったかった","言いたかった"],["やったかった","やりたかった"],["作ったかった","作りたかった"],
  ["会ったかった","会いたかった"],["持ったかった","持ちたかった"],["分かったかった","分かりたかった"],
];
function fixWish(s){
  if(!s) return s;
  let t = String(s);
  for(const [a,b] of WISH_FIXES){ t = t.split(a).join(b); }
  return t;
}

/* ---------- robust JSON extraction ---------- */
function extractJSON(text){
  if(!text) return null;
  const start = text.indexOf("{");
  if(start < 0) return null;
  for(let end = text.length; end > start; end--){
    if(text[end-1] !== "}") continue;
    try { return JSON.parse(text.slice(start, end)); } catch(e){}
  }
  try { return JSON.parse(text); } catch(e){ return null; }
}

/* ---------- Groq call with model fallback ---------- */
async function callGroq(apiKey, sys, user){
  const models = ["openai/gpt-oss-120b", "llama-3.3-70b-versatile"];
  for(const model of models){
    try{
      const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + apiKey },
        body: JSON.stringify({
          model,
          temperature: 0.7,
          max_tokens: 2048,
          response_format: { type: "json_object" },
          messages: [ { role: "system", content: sys }, { role: "user", content: user } ],
        }),
      });
      if(!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      const txt = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || "";
      const j = extractJSON(txt);
      if(j && Array.isArray(j.options) && j.options.length >= 1) return j;
      throw new Error("bad json");
    }catch(e){ /* try next model */ }
  }
  return null;
}

/* ---------- offline candidate banks ---------- */
const NEG_BANK = [
  { keys:["仕事","上司","会社","職場","残業","同僚","保育","園","先生","お客"], options:[
    "どれだけ頑張っても認めてもらえないのではと、悔しさがこみ上げた",
    "この忙しさがずっと続くのではないかと、不安で胸が重くなった",
    "自分ばかり損をしているようで、腹が立った",
  ]},
  { keys:["彼","彼女","夫","妻","旦那","恋","パートナー","好きな人"], options:[
    "大切にされていないのではと、悲しくなった",
    "気持ちがすれ違ったまま戻れないのではと、怖くなった",
    "どうして分かってくれないのかと、もどかしさで胸が締め付けられた",
  ]},
  { keys:["親","母","父","家族","子ども","子供","息子","娘","兄","姉","弟","妹","義理"], options:[
    "家族なのに分かり合えていないのではと、寂しくなった",
    "自分の思いはいつも後回しにされている気がして、悲しくなった",
    "どうしてこちらの気持ちを察してくれないのかと、苛立ちを感じた",
  ]},
  { keys:["友","友達","友人","ママ友","仲間"], options:[
    "本当は大事に思われていないのではと、寂しさが押し寄せた",
    "自分だけが気を遣っている気がして、悔しくなった",
    "このまま距離が離れていくのではと、不安になった",
  ]},
  { keys:["お金","給料","貯金","出費","値上げ","家計"], options:[
    "このままではやっていけないのではと、不安で落ち着かなくなった",
    "頑張っているのに報われていない気がして、悔しくなった",
    "将来の備えができていないのではと、焦りを感じた",
  ]},
  { keys:["自分","疲れ","体","ダイエット","続かない","やる気","習慣"], options:[
    "自分には続ける力がないのではと、無力感を覚えた",
    "また同じことを繰り返すのではと、自分に腹が立った",
    "このまま変われないのではないかと、焦りがこみ上げた",
  ]},
];
const NEG_DEFAULT = [
  "自分の思いが届いていないのではと、悲しくなった",
  "この状況がずっと変わらないのではと、不安になった",
  "どうにもできない自分がもどかしくて、悔しくなった",
];

const DES_BANK = [
  { keys:["悔し"], options:[
    { wish:"自分の頑張りを、自分でちゃんと誇りたかった", vow:"自分の頑張りを自分で誇る" },
    { wish:"結果に振り回されず、堂々と進みたかった", vow:"堂々と自分の道を進む" },
    { wish:"悔しさを力に変えて、次の一歩を踏み出したかった", vow:"悔しさを力に変えて進む" },
  ]},
  { keys:["不安","怖","恐","焦"], options:[
    { wish:"未来を信じて、安心して今日を過ごしたかった", vow:"未来を信じて今日を生きる" },
    { wish:"どっしり構えて、目の前のことを楽しみたかった", vow:"どっしり構えて今を楽しむ" },
    { wish:"自分の選択を信じて、迷わず進みたかった", vow:"自分の選択を信じて進む" },
  ]},
  { keys:["悲し","寂し"], options:[
    { wish:"自分の気持ちを、素直に言葉にしたかった", vow:"自分の気持ちを素直に伝える" },
    { wish:"大切な人と、心を開いて向き合いたかった", vow:"心を開いて向き合う" },
    { wish:"自分のことを、自分でいちばん大切にしたかった", vow:"自分をいちばん大切にする" },
  ]},
  { keys:["腹が立","苛立","もどかし"], options:[
    { wish:"落ち着いて、自分の思いをまっすぐ伝えたかった", vow:"落ち着いて思いを伝える" },
    { wish:"相手に期待するより、自分から動きたかった", vow:"自分から動く" },
    { wish:"心に余裕を持って、穏やかに過ごしたかった", vow:"余裕を持って穏やかに過ごす" },
  ]},
  { keys:["無力","劣等","絶望"], options:[
    { wish:"小さな一歩を、自分の力で積み重ねたかった", vow:"小さな一歩を積み重ねる" },
    { wish:"自分の可能性を、最後まで信じたかった", vow:"自分の可能性を信じる" },
    { wish:"できたことに目を向けて、自分を励ましたかった", vow:"できたことに目を向ける" },
  ]},
];
const DES_DEFAULT = [
  { wish:"自分の気持ちに正直に生きたかった", vow:"自分の気持ちに正直に生きる" },
  { wish:"毎日を、心から楽しみたかった", vow:"毎日を心から楽しむ" },
  { wish:"自分の大切なものを、大切にしたかった", vow:"大切なものを大切にする" },
];

const EMO_BANK = [
  { keys:["伝え","向き合","開く"], options:[
    { emotion:"伝え合える絆", note:"想いを伝え、相手の想いも受けとれる繋がり。" },
    { emotion:"分かり合えているという確信", note:"言葉にしなくても通じ合える、深い安心。" },
    { emotion:"心が通い合う温かさ", note:"そばにいるだけで満たされる、やわらかな時間。" },
  ]},
  { keys:["信じ"], options:[
    { emotion:"未来を信じられる安心感", note:"明日が楽しみになる、心の土台。" },
    { emotion:"揺るがない自信", note:"何があっても大丈夫と思える、静かな強さ。" },
    { emotion:"信頼し合える強さ", note:"互いを信じ合える、揺るがない関係。" },
  ]},
  { keys:["誇","頑張","積み重ね","目を向け"], options:[
    { emotion:"自分を誇れる充実感", note:"今日の自分に、まるをつけられる嬉しさ。" },
    { emotion:"満たされた達成感", note:"積み重ねてきたものが実を結ぶ喜び。" },
    { emotion:"胸を張れる誇らしさ", note:"誰かの評価がなくても、堂々といられる気持ち。" },
  ]},
  { keys:["楽し","穏やか","余裕"], options:[
    { emotion:"心から笑える喜び", note:"理由がなくても、ふっと笑顔になれる毎日。" },
    { emotion:"満ち足りた穏やかさ", note:"何も心配せず、今この瞬間を味わえる心。" },
    { emotion:"軽やかな自由", note:"やりたいことに、素直に手を伸ばせる身軽さ。" },
  ]},
  { keys:["大切","大事"], options:[
    { emotion:"無条件の愛で包み込まれる安心感", note:"そのままの自分で、愛されているという確信。" },
    { emotion:"自分にやさしくできる温もり", note:"自分をいたわることを、自分に許せる幸せ。" },
    { emotion:"かけがえのない存在だという実感", note:"ここにいていいと、心から思える安らぎ。" },
  ]},
  { keys:["進","動く","一歩","可能性"], options:[
    { emotion:"胸が高鳴るわくわく", note:"新しい一歩の先が、楽しみでたまらない気持ち。" },
    { emotion:"自分の力を信じられる確信", note:"わたしなら大丈夫と、迷いなく思える強さ。" },
    { emotion:"前に進む晴れやかさ", note:"視界が開けて、足取りが軽くなる感覚。" },
  ]},
];
const EMO_DEFAULT = [
  { emotion:"満ち足りた幸福感", note:"心のすみずみまで、あたたかさが行き渡る感じ。" },
  { emotion:"ありのままでいられる安心感", note:"何も飾らなくても、ここにいていいという安らぎ。" },
  { emotion:"心が通い合う温かさ", note:"大切な人と、想いを分かち合える喜び。" },
];

function pickBank(bank, def, text){
  const t = String(text || "");
  for(const b of bank){ if(b.keys.some(k => t.indexOf(k) >= 0)) return b.options; }
  return def;
}

/* regenerate-aware offline pick: matched bank first, then other banks, excluding shown */
function offlinePick(bank, def, text, exclude, keyFn){
  const matched = pickBank(bank, def, text);
  const others = bank.flatMap(b => b.options).concat(def).filter(o => matched.indexOf(o) < 0);
  for(let i = others.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i + 1));
    const t = others[i]; others[i] = others[j]; others[j] = t;
  }
  const pool = matched.concat(others);
  const fresh = pool.filter(o => exclude.indexOf(keyFn(o)) < 0);
  return (fresh.length >= 3 ? fresh : pool).slice(0, 3);
}

/* ---------- wishes persistence ---------- */
const WISH_KEY = "negaigumo_wishes";
const KINGDOM_KEY = "negaigumo_kingdom";
function loadKingdom(){ try { return JSON.parse(store.get(KINGDOM_KEY) || "[]") || []; } catch(e){ return []; } }
function saveKingdom(k){ store.set(KINGDOM_KEY, JSON.stringify(k)); }
function loadWishes(){ try { return JSON.parse(store.get(WISH_KEY) || "[]") || []; } catch(e){ return []; } }
function saveWishes(w){ store.set(WISH_KEY, JSON.stringify(w)); }

/* ---------- styles ---------- */
const F_HEAD = "'Mochiy Pop One', sans-serif";
const F_BODY = "'Zen Maru Gothic', sans-serif";
const F_HAND = "'Yomogi', cursive";
const RAINBOW = "linear-gradient(92deg,#6FAFFF 0%,#A98BFF 30%,#FF8FC0 62%,#FFB57E 100%)";
const cardStyle = {
  background:"linear-gradient(160deg, rgba(255,255,255,.62), rgba(255,255,255,.44)) padding-box, " +
             "linear-gradient(135deg, rgba(255,255,255,.95), rgba(165,200,255,.7) 40%, rgba(255,175,220,.7)) border-box",
  border:"1.5px solid transparent",
  backdropFilter:"blur(18px) saturate(1.35)", WebkitBackdropFilter:"blur(18px) saturate(1.35)",
  borderRadius:28, padding:"24px 20px",
  boxShadow:"0 18px 44px rgba(110,130,195,.28), inset 0 1px 0 rgba(255,255,255,.7)",
};
const btnPrimary = {
  fontFamily:F_HEAD, fontSize:15, color:"#fff", border:"none", cursor:"pointer",
  background:"linear-gradient(120deg,#8FC5FF,#C9A8FF,#FFA9CC)", borderRadius:999,
  padding:"13px 28px", letterSpacing:".05em",
  boxShadow:"0 10px 26px rgba(160,140,230,.45), inset 0 1px 0 rgba(255,255,255,.5)",
  position:"relative", overflow:"hidden",
};
const btnGhost = {
  fontFamily:F_BODY, fontWeight:700, fontSize:13, color:"#66739F", cursor:"pointer",
  background:"rgba(255,255,255,.55)", border:"1.5px solid rgba(255,255,255,.85)",
  backdropFilter:"blur(8px)", WebkitBackdropFilter:"blur(8px)",
  borderRadius:999, padding:"9px 18px",
  boxShadow:"0 4px 14px rgba(130,150,210,.18)",
};
const optionBtn = {
  display:"block", width:"100%", textAlign:"left", cursor:"pointer",
  background:"linear-gradient(150deg, rgba(255,255,255,.58), rgba(255,255,255,.4)) padding-box, " +
             "linear-gradient(120deg, rgba(160,200,255,.85), rgba(255,175,220,.75)) border-box",
  border:"1.5px solid transparent",
  backdropFilter:"blur(10px)", WebkitBackdropFilter:"blur(10px)",
  borderRadius:20, padding:"16px 18px", marginTop:12,
  fontFamily:F_BODY, fontSize:15, lineHeight:1.75, color:"#414D74",
  boxShadow:"0 6px 16px rgba(140,160,220,.2), inset 0 1px 0 rgba(255,255,255,.6)",
};

function Milly({src, size, style}){
  return <img src={src} alt="ミリィ" style={{ width:size, height:"auto", display:"block", ...style }} />;
}

/* 2.5Dペーパーパペット：羽ばたき＋呼吸＋輪っかの浮遊＋指に反応する立体視差 */
function MillyPuppet({ size, style, flapDur = 1.8 }){
  const [tilt, setTilt] = useState({ x:0, y:0 });
  function onMove(e){
    const r = e.currentTarget.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    setTilt({ x: ((cx - r.left)/r.width - .5) * 16, y: ((cy - r.top)/r.height - .5) * 16 });
  }
  function onLeave(){ setTilt({ x:0, y:0 }); }
  return (
    <div style={{ width:size, margin:"0 auto", perspective:"620px", touchAction:"pan-y", ...style }}
      onPointerMove={onMove} onPointerLeave={onLeave} onTouchMove={onMove} onTouchEnd={onLeave}>
      <div style={{ transform:`rotateY(${tilt.x}deg) rotateX(${-tilt.y}deg)`,
        transformStyle:"preserve-3d", transition:"transform .3s ease-out" }}>
        <div style={{ position:"relative", width:"100%", paddingTop:"104.2%",
          transformStyle:"preserve-3d", animation:"hoverFloat 3.1s ease-in-out infinite" }}>
          <div style={{ position:"absolute", inset:0, transform:"translateZ(-26px)" }}>
            <div className="millyGlow" aria-hidden="true" />
            <img src={M_WING_L} alt="" style={{ position:"absolute", inset:0, width:"100%",
              transformOrigin:"27.8% 44%", animation:`flapL ${flapDur}s ease-in-out infinite` }} />
            <img src={M_WING_R} alt="" style={{ position:"absolute", inset:0, width:"100%",
              transformOrigin:"72.5% 43.3%", animation:`flapR ${flapDur}s ease-in-out infinite` }} />
          </div>
          <img src={M_BODY} alt="ミリィ" style={{ position:"absolute", inset:0, width:"100%",
            transformOrigin:"50% 62%", animation:"breathe 3.6s ease-in-out infinite" }} />
          <img src={M_HALO} alt="" aria-hidden="true" style={{ position:"absolute", inset:0, width:"100%",
            animation:"haloBob 3.2s ease-in-out infinite" }} />
        </div>
        <div className="hoverShadow" aria-hidden="true" />
      </div>
    </div>
  );
}

const LAYER_NAMES = { 1:"ゆうやけの層", 2:"たそがれの層", 3:"ほしぞらの層" };
function StepBadge({n}){
  return (
    <div style={{ display:"inline-flex", alignItems:"center", gap:8 }}>
      <span style={{ fontFamily:F_HEAD, fontSize:12, color:"#fff",
        background:RAINBOW, borderRadius:999, padding:"5px 16px", letterSpacing:".12em" }}>
        STEP {n} / 3
      </span>
      <span style={{ fontFamily:F_HAND, fontSize:12, color:"#8A96BC" }}>✦ {LAYER_NAMES[n]}</span>
    </div>
  );
}

/* ---------- dreamy background: clouds / rainbow / twinkles ---------- */
const SKYS = [
  "linear-gradient(180deg,#EAF5FF,#FFE9F3)",                                  /* 0 ひるの空 */
  "linear-gradient(180deg,#DCEBFF 0%,#FFDCE4 55%,#FFE7CC 100%)",              /* 1 ゆうやけ */
  "linear-gradient(180deg,#C9DAFF 0%,#DACEF8 55%,#F7D6E8 100%)",              /* 2 たそがれ */
  "linear-gradient(180deg,#93A9E4 0%,#A794E2 55%,#CBA9DF 100%)",              /* 3 ほしぞら */
  "linear-gradient(180deg,#7E93DC 0%,#8F7FD4 45%,#BE93D6 100%)",              /* 4 ねがいの宇宙 */
];
const STAR_DOTS = [
  [6,8,3],[14,22,2],[24,6,3],[33,16,2],[44,9,3],[52,20,2],[63,7,3],[72,15,2],[83,10,3],[92,22,2],
  [9,38,2],[28,44,3],[48,36,2],[68,42,3],[88,38,2],
  [12,60,3],[34,66,2],[56,58,3],[78,64,2],[94,58,3],
  [8,82,2],[26,88,3],[47,80,2],[66,90,3],[85,82,2],[96,74,2],
];
function DreamLayer({ phase }){
  const starOp  = [0, .25, .55, .85, 1][phase];
  const cloudOp = [1, .9, .7, .45, .3][phase];
  const clouds = [
    { top:"7%",  size:110, dur:75,  delay:-10, op:.95 },
    { top:"18%", size:70,  dur:100, delay:-55, op:.75 },
    { top:"34%", size:130, dur:130, delay:-90, op:.55 },
    { top:"52%", size:85,  dur:90,  delay:-25, op:.65 },
    { top:"68%", size:115, dur:115, delay:-70, op:.5  },
    { top:"84%", size:75,  dur:105, delay:-40, op:.6  },
  ];
  const twinkles = [
    [8,12],[22,6],[38,17],[55,8],[72,14],[88,10],
    [12,44],[90,40],[6,72],[30,88],[64,92],[93,78],
  ];
  return (
    <div aria-hidden="true" style={{ position:"fixed", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:0 }}>
      {SKYS.map((g, i) => (
        <div key={i} style={{ position:"absolute", inset:0, background:g,
          opacity: phase === i ? 1 : 0, transition:"opacity 1.8s ease" }} />
      ))}
      <div className="rainbowArc" style={{ opacity: phase <= 2 ? .8 : .35, transition:"opacity 1.8s ease" }} />
      <div className="moon" style={{ opacity: phase >= 2 ? .95 : 0, transition:"opacity 1.8s ease" }} />
      {phase >= 3 && <div className="aurora" />}
      <div style={{ position:"absolute", inset:0, opacity:starOp, transition:"opacity 1.8s ease" }}>
        {STAR_DOTS.map(([x, y, s], i) => (
          <span key={i} className="star" style={{ left:x+"%", top:y+"%", width:s, height:s,
            animationDelay:(i * 0.31) % 2.6 + "s" }} />
        ))}
      </div>
      <div style={{ position:"absolute", inset:0, opacity:cloudOp, transition:"opacity 1.8s ease" }}>
        {clouds.map((c, i) => (
          <div key={i} className="cloud" style={{ top:c.top, width:c.size, height:c.size*0.38,
            opacity:c.op, animationDuration:c.dur+"s", animationDelay:c.delay+"s" }} />
        ))}
      </div>
      {twinkles.map(([x, y], i) => (
        <span key={i} className="twinkle" style={{ left:x+"%", top:y+"%", animationDelay:(i*0.55)+"s" }}>✦</span>
      ))}
      {phase === 4 && (
        <>
          <span className="shooting" style={{ left:"8%",  top:"10%" }} />
          <span className="shooting" style={{ left:"55%", top:"5%",  animationDelay:"2.3s" }} />
          <span className="shooting" style={{ left:"30%", top:"26%", animationDelay:"4.1s" }} />
        </>
      )}
    </div>
  );
}

/* 最前面をただよう光の粒（タッチは透過） */
function MoteLayer(){
  return (
    <div aria-hidden="true" style={{ position:"fixed", inset:0, overflow:"hidden",
      pointerEvents:"none", zIndex:5 }}>
      {[14, 32, 50, 66, 82, 92, 24, 42, 74].map((x, i) => (
        <span key={i} className="mote" style={{ left:x+"%",
          animationDuration:(13 + i*2.1)+"s", animationDelay:(-i*2.9)+"s" }} />
      ))}
    </div>
  );
}

/* ==================================================================== */
export default function App(){
  const [screen, setScreen] = useState("key");   // key|vent|step1|step2|step3|reveal|order|list
  const [apiKey, setApiKey] = useState("");
  const [keyInput, setKeyInput] = useState("");
  const [online, setOnline] = useState(false);
  const [vent, setVent] = useState("");
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [negOptions, setNegOptions] = useState([]);
  const [desOptions, setDesOptions] = useState([]);
  const [emoOptions, setEmoOptions] = useState([]);
  const [chosenNeg, setChosenNeg] = useState("");
  const [chosenDes, setChosenDes] = useState(null);
  const [chosenEmo, setChosenEmo] = useState(null);
  const [negSeen, setNegSeen] = useState([]);
  const [desSeen, setDesSeen] = useState([]);
  const [emoSeen, setEmoSeen] = useState([]);
  const [wishes, setWishes] = useState([]);
  const [saved, setSaved] = useState(false);
  const [orderDone, setOrderDone] = useState(false);
  const [showKeyHelp, setShowKeyHelp] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("ミリィが、心の声に耳をすませているよ…");
  const [islands, setIslands] = useState([]);
  const [islandName, setIslandName] = useState("");
  const topRef = useRef(null);

  useEffect(() => {
    const k = store.get("negaigumo_key") || "";
    if(k && k.indexOf("gsk_") === 0){ setApiKey(k); setOnline(true); setScreen("vent"); }
    setWishes(loadWishes());
    setIslands(loadKingdom());
    try { const b = document.getElementById("boot"); if(b) b.remove(); } catch(e){}
  }, []);

  useEffect(() => { try { window.scrollTo({top:0, behavior:"smooth"}); } catch(e){} }, [screen]);

  function startWithKey(){
    const k = keyInput.trim();
    if(k.indexOf("gsk_") === 0){
      store.set("negaigumo_key", k);
      setApiKey(k); setOnline(true);
    } else {
      store.del("negaigumo_key");
      setApiKey(""); setOnline(false);
    }
    setNotice(""); setScreen("vent");
  }
  function startOffline(){
    store.del("negaigumo_key");
    setApiKey(""); setOnline(false); setNotice(""); setScreen("vent");
  }

  async function askAI(sys, user, offlineFn){
    if(online && apiKey){
      const j = await callGroq(apiKey, sys, user);
      if(j) return { options:j.options, offline:false };
      return { options: offlineFn(), offline:true, fellBack:true };
    }
    await new Promise(r => setTimeout(r, 700));
    return { options: offlineFn(), offline:true };
  }

  async function goStep1(regen){
    if(!vent.trim()) return;
    setLoadingMsg("ミリィが、ことばの奥に耳をすませているよ…");
    setLoading(true); setNotice("");
    const exclude = regen ? negSeen : [];
    let user = `愚痴：「${vent.trim()}」\nこの愚痴の奥にある"痛み"の候補を3つ、それぞれ別々の感情で、重複なく出してください。`;
    if(exclude.length) user += `\n以下は提示済みです。これらと重複・類似しない、新しい切り口の候補を出してください：${exclude.map(s => "「" + s + "」").join("、")}`;
    const r = await askAI(NEG_SYS, user, () => offlinePick(NEG_BANK, NEG_DEFAULT, vent, exclude, o => o));
    const opts = r.options.slice(0,3).map(o => fixNeg(typeof o === "string" ? o : String(o)));
    setNegOptions(opts);
    setNegSeen(exclude.concat(opts));
    if(r.fellBack) setNotice("通信がうまくいかなかったので、ミリィの直感でお届けします。");
    setLoading(false); setScreen("step1");
  }

  async function goStep2(neg, regen){
    setChosenNeg(neg);
    setLoadingMsg("痛みを、そっと裏返しているよ…");
    setLoading(true); setNotice("");
    const exclude = regen ? desSeen : [];
    let user = `愚痴：「${vent.trim()}」\n選ばれた痛み：「${neg}」\nこの痛みを裏返した「本当はこんな自分でいたかった」の候補を3つ、同じ方向の別の側面で、重複なく出してください。`;
    if(exclude.length) user += `\n以下は提示済みです。これらと重複・類似しない、新しい切り口の候補を出してください：${exclude.map(s => "「" + s + "」").join("、")}`;
    const r = await askAI(DES_SYS, user, () => offlinePick(DES_BANK, DES_DEFAULT, neg, exclude, o => o.wish));
    const opts = r.options.slice(0,3).map(o => ({ wish: fixWish(o && o.wish), vow: (o && o.vow) || "" }));
    setDesOptions(opts);
    setDesSeen(exclude.concat(opts.map(o => o.wish)));
    if(r.fellBack) setNotice("通信がうまくいかなかったので、ミリィの直感でお届けします。");
    setLoading(false); setScreen("step2");
  }

  async function goStep3(des, regen){
    setChosenDes(des);
    setLoadingMsg("願いの核へ、のぼっていくよ…");
    setLoading(true); setNotice("");
    const exclude = regen ? emoSeen : [];
    let user = `愚痴：「${vent.trim()}」\n選ばれた痛み：「${chosenNeg}」\nなりたい自分：「${des.vow}」\nこの自分像の奥で本当に欲しかった気持ち・状態の候補を3つ、同じ核の別の濃淡で、重複なく出してください。`;
    if(exclude.length) user += `\n以下は提示済みです。これらと重複・類似しない、新しい切り口の候補を出してください：${exclude.map(s => "「" + s + "」").join("、")}`;
    const r = await askAI(EMO_SYS, user, () => offlinePick(EMO_BANK, EMO_DEFAULT, des.vow + des.wish, exclude, o => o.emotion));
    const opts = r.options.slice(0,3).map(o => ({ emotion:(o && o.emotion) || "", note:(o && o.note) || "" }));
    setEmoOptions(opts);
    setEmoSeen(exclude.concat(opts.map(o => o.emotion)));
    if(r.fellBack) setNotice("通信がうまくいかなかったので、ミリィの直感でお届けします。");
    setLoading(false); setScreen("step3");
  }

  async function goReveal(emo){
    setChosenEmo(emo); setSaved(false);
    setLoadingMsg("ねがいの空へ──");
    setLoading(true);
    await new Promise(r => setTimeout(r, 1100));
    setLoading(false); setScreen("reveal");
  }

  function saveWish(){
    const w = {
      id: Date.now(),
      neg: chosenNeg,
      wish: chosenDes ? chosenDes.wish : "",
      vow: chosenDes ? chosenDes.vow : "",
      emo: chosenEmo ? chosenEmo.emotion : "",
      note: chosenEmo ? chosenEmo.note : "",
    };
    const next = [w, ...wishes];
    setWishes(next); saveWishes(next); setSaved(true);
    setScreen("list");
  }

  function restart(){
    setVent(""); setNegOptions([]); setDesOptions([]); setEmoOptions([]);
    setChosenNeg(""); setChosenDes(null); setChosenEmo(null);
    setNegSeen([]); setDesSeen([]); setEmoSeen([]);
    setSaved(false); setNotice(""); setScreen("vent");
  }

  const [demoMode, setDemoMode] = useState(() => {
    try { return /demo=1|#demo/.test(window.location.href); } catch(e){ return false; }
  });
  const demoTaps = useRef(0);
  function footerTap(){
    demoTaps.current += 1;
    if(demoTaps.current >= 5){ demoTaps.current = 0; setDemoMode(v => !v); }
  }

  function fillDemoWishes(){
    const samples = [
      { neg:"どれだけ頑張っても認めてもらえないのではと、悔しさがこみ上げた", vow:"自分の頑張りを自分で誇る", emo:"自分を誇れる充実感" },
      { neg:"この忙しさがずっと続くのではないかと、不安で胸が重くなった", vow:"未来を信じて今日を生きる", emo:"未来を信じられる安心感" },
      { neg:"大切にされていないのではと、悲しくなった", vow:"自分の気持ちを素直に伝える", emo:"伝え合える絆" },
      { neg:"どうして分かってくれないのかと、もどかしさで胸が締め付けられた", vow:"落ち着いて思いを伝える", emo:"分かり合えているという確信" },
      { neg:"家族なのに分かり合えていないのではと、寂しくなった", vow:"心を開いて向き合う", emo:"心が通い合う温かさ" },
      { neg:"自分だけが気を遣っている気がして、悔しくなった", vow:"自分から動く", emo:"胸が高鳴るわくわく" },
      { neg:"このままではやっていけないのではと、不安で落ち着かなくなった", vow:"どっしり構えて今を楽しむ", emo:"満ち足りた穏やかさ" },
      { neg:"自分には続ける力がないのではと、無力感を覚えた", vow:"小さな一歩を積み重ねる", emo:"自分の力を信じられる確信" },
      { neg:"また同じことを繰り返すのではと、自分に腹が立った", vow:"できたことに目を向ける", emo:"胸を張れる誇らしさ" },
      { neg:"このまま変われないのではないかと、焦りがこみ上げた", vow:"自分の可能性を信じる", emo:"前に進む晴れやかさ" },
    ];
    const next = samples.map((s, i) => ({ id: Date.now() + i, ...s, wish:"", note:"" })).concat(wishes);
    setWishes(next); saveWishes(next);
  }

  function deleteWish(id){
    const next = wishes.filter(w => w.id !== id);
    setWishes(next); saveWishes(next);
  }

  function makeIsland(){
    const name = islandName.trim() || `第${islands.length + 1}の島`;
    const island = {
      id: Date.now(), name,
      date: new Date().toLocaleDateString("ja-JP"),
      emos: wishes.slice(0, 10).map(w => w.emo),
    };
    const next = [...islands, island];
    setIslands(next); saveKingdom(next);
    setWishes([]); saveWishes([]);
    setOrderDone(false); setIslandName("");
    setScreen("kingdom");
  }

  const narrate = (w) => `「${w.neg}」が嫌で、${w.vow}という私でいたくて、本当は「${w.emo}」が欲しかった`;

  function millyLine(n){
    if(n === 1) return "はじめての願い、みつけたね！ミリィが大切にあずかっておくよ";
    if(n === 5) return "5個目！願いの雲が、ふんわりふくらんできたよ";
    if(n >= 10) return "10個そろったよ…！5次元オーダーの準備が、ととのったみたい";
    return n + "個目の願い、たしかにあずかったよ！";
  }

  const PHASE_MAP = { key:0, vent:0, list:2, step1:1, step2:2, step3:3, reveal:4, order:4, kingdom:4 };
  const phase = PHASE_MAP[screen] != null ? PHASE_MAP[screen] : 0;

  /* ---------------- render helpers ---------------- */
  const header = (
    <header style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
      flexWrap:"wrap", gap:10, padding:"14px 4px 18px" }}>
      <div style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}
        onClick={() => setScreen(apiKey || !online ? "vent" : "key")}>
        <Milly src={MILLY_STD} size={44} style={{ filter:"drop-shadow(0 3px 6px rgba(150,170,220,.4))" }} />
        <span style={{ fontFamily:F_HEAD, fontSize:22, letterSpacing:".06em",
          background:RAINBOW, backgroundSize:"200% 100%", WebkitBackgroundClip:"text",
          backgroundClip:"text", color:"transparent", animation:"hueSlide 7s linear infinite" }}>
          ねがいぐも
        </span>
      </div>
      <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
        <button className="btnG" style={{ ...btnGhost, whiteSpace:"nowrap" }} onClick={() => { setKeyInput(""); setScreen("key"); }}>鍵を変更</button>
        <button className="btnG" style={{ ...btnGhost, whiteSpace:"nowrap" }} onClick={() => { setSaved(false); setScreen("list"); }}>
          願い事リスト{wishes.length ? `（${wishes.length}）` : ""}
        </button>
      </div>
    </header>
  );

  const modeBadge = (
    <div style={{ textAlign:"center", marginBottom:14 }}>
      <span style={{ fontFamily:F_BODY, fontSize:11, fontWeight:700, borderRadius:999, padding:"4px 14px",
        color: online ? "#3E8E67" : "#8A7FB8",
        background: online ? "rgba(190,240,215,.6)" : "rgba(225,215,250,.6)" }}>
        {online ? "オンライン（Groq接続中）" : "オフラインモード"}
      </span>
    </div>
  );

  const loadingView = (
    <div style={{ textAlign:"center", padding:"64px 0 72px", position:"relative", overflow:"hidden" }}>
      <div aria-hidden="true" style={{ position:"absolute", inset:0, pointerEvents:"none" }}>
        {[0,1,2,3,4,5].map(i => (
          <span key={i} className="streak" style={{ left:(10 + i*15.5)+"%", animationDelay:(i*0.28)+"s" }} />
        ))}
      </div>
      <div style={{ position:"relative", width:170, margin:"0 auto" }}>
        <MillyPuppet size={155} flapDur={1.15} />
        <span className="twinkle" style={{ left:-10, top:22, animationDelay:"0s" }}>✦</span>
        <span className="twinkle" style={{ right:-8, top:52, animationDelay:".9s" }}>✦</span>
        <span className="twinkle" style={{ left:26, bottom:-4, animationDelay:"1.7s" }}>✦</span>
      </div>
      <p style={{ fontFamily:F_HAND, fontSize:16, marginTop:24, position:"relative",
        color: phase >= 3 ? "rgba(255,255,255,.95)" : "#66739F",
        textShadow: phase >= 3 ? "0 1px 10px rgba(90,80,160,.6)" : "none" }}>
        {loadingMsg}
      </p>
    </div>
  );

  function renderScreen(){
    if(loading) return loadingView;

    if(screen === "key") return (
      <div style={{ ...cardStyle, textAlign:"center" }}>
        <MillyPuppet size={190} style={{ margin:"6px auto 4px" }} />
        <h1 style={{ fontFamily:F_HEAD, fontSize:23, color:"#5B6BA8", margin:"8px 0 4px" }}>ねがいぐもを ひらく鍵</h1>
        <p style={{ fontFamily:F_BODY, fontSize:14, lineHeight:1.9, color:"#6E7A9E", margin:"6px 0 4px" }}>
          痛みの奥にかくれている「ほんとうの願い」を、<br/>天使イルカのミリィと一緒に見つけにいこう。
        </p>
        <p style={{ fontFamily:F_HAND, fontSize:13, lineHeight:1.9, color:"#8A96BC", margin:"0 0 16px" }}>
          ミリィがあなたの言葉を読みとくために、<br/>AIの鍵（Groq APIキー）を使うよ。
        </p>
        <input
          type="password"
          value={keyInput}
          onChange={e => setKeyInput(e.target.value)}
          placeholder="gsk_ から始まるGroqの鍵を貼り付け"
          style={{ width:"100%", boxSizing:"border-box", fontFamily:F_BODY, fontSize:14,
            padding:"13px 16px", borderRadius:14, border:"1.5px solid #D7E3F7",
            background:"#F7FAFF", color:"#4A5578", outline:"none" }}
        />
        <p style={{ fontFamily:F_BODY, fontSize:11, lineHeight:1.8, color:"#9AA6C8", margin:"8px 0 16px" }}>
          鍵はこの端末の中にだけ保存されます。<br/>Groqの無料枠の範囲で動くので、料金はかかりません。
        </p>
        <div style={{ display:"flex", flexDirection:"column", gap:10, alignItems:"center" }}>
          <button className="btnP" style={btnPrimary} onClick={startWithKey}>ねがいぐもを ひらく</button>
          <button className="btnG" style={btnGhost} onClick={startOffline}>鍵なしでためす（やさしい候補で遊ぶ）</button>
        </div>
        <div style={{ marginTop:20, paddingTop:16, borderTop:"1.5px dashed #E3ECFA" }}>
          <a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer"
            style={{ fontFamily:F_BODY, fontWeight:700, fontSize:13, color:"#6E8FD8" }}>
            無料でGroqの鍵を取得する（カード不要）→
          </a>
          <div style={{ marginTop:8 }}>
            <button className="btnG" style={{ ...btnGhost, fontSize:12 }} onClick={() => setShowKeyHelp(!showKeyHelp)}>
              {showKeyHelp ? "とじる" : "取り方を見る"}
            </button>
          </div>
          {showKeyHelp && (
            <ol style={{ textAlign:"left", fontFamily:F_BODY, fontSize:12.5, lineHeight:2,
              color:"#6E7A9E", margin:"12px 0 0", paddingLeft:22 }}>
              <li>上のリンクからGroqのサイトを開く（無料登録・カード不要）</li>
              <li>Googleアカウントかメールアドレスでサインアップ</li>
              <li>「Create API Key」を押して、好きな名前をつける</li>
              <li>表示された「gsk_」から始まる文字列をコピーして、ここに貼り付け</li>
            </ol>
          )}
        </div>
      </div>
    );

    if(screen === "vent") return (
      <div>
        {modeBadge}
        <div style={{ ...cardStyle }}>
          <div style={{ display:"flex", alignItems:"flex-end", gap:12 }}>
            <MillyPuppet size={92} style={{ margin:0 }} flapDur={2.1} />
            <div style={{ position:"relative", flex:1, background:"#F4F9FF", borderRadius:"18px 18px 18px 4px",
              padding:"12px 14px", fontFamily:F_HAND, fontSize:14.5, lineHeight:1.8, color:"#5B6BA8" }}>
              今日はどんなことがあった?<br/>モヤモヤ、そのまま話してみて。
            </div>
          </div>
          <textarea
            value={vent}
            onChange={e => setVent(e.target.value)}
            rows={5}
            maxLength={300}
            placeholder="例）頑張って準備したのに、誰にも気づいてもらえなかった…"
            style={{ width:"100%", boxSizing:"border-box", marginTop:16, fontFamily:F_BODY, fontSize:15,
              lineHeight:1.8, padding:"14px 16px", borderRadius:16, border:"1.5px solid #D7E3F7",
              background:"#FDFDFF", color:"#4A5578", outline:"none", resize:"vertical" }}
          />
          <div style={{ textAlign:"right", fontFamily:F_BODY, fontSize:11, color:"#B0BBD8", marginTop:4 }}>
            {vent.length} / 300
          </div>
          <div style={{ textAlign:"center", marginTop:14 }}>
            <button className="btnP" style={{ ...btnPrimary, opacity: vent.trim() ? 1 : .5 }} disabled={!vent.trim()} onClick={goStep1}>
              ミリィに聞いてもらう
            </button>
          </div>
        </div>
      </div>
    );

    if(screen === "step1") return (
      <div>
        {notice && <p style={{ fontFamily:F_BODY, fontSize:12, color:"#B08AC4", textAlign:"center", marginBottom:10 }}>{notice}</p>}
        <div style={{ ...cardStyle }}>
          <StepBadge n={1} />
          <h2 style={{ fontFamily:F_HEAD, fontSize:18, color:"#5B6BA8", margin:"12px 0 4px" }}>その愚痴の奥にあった痛み</h2>
          <p style={{ fontFamily:F_BODY, fontSize:13.5, lineHeight:1.8, color:"#6E7A9E", margin:"0 0 6px" }}>
            心にいちばん近いものを、ひとつ選んでね。
          </p>
          {negOptions.map((o, i) => (
            <button key={i} className="opt" style={{ ...optionBtn, animation:`fadeUp .45s ${i*0.12}s both ease-out` }} onClick={() => goStep2(o)}>{o}</button>
          ))}
          <div style={{ display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap", marginTop:18 }}>
            <button className="btnG" style={btnGhost} onClick={() => goStep1(true)}>🔁 別の候補を見る</button>
            <button className="btnG" style={btnGhost} onClick={() => setScreen("vent")}>← 愚痴を書き直す</button>
          </div>
        </div>
      </div>
    );

    if(screen === "step2") return (
      <div>
        {notice && <p style={{ fontFamily:F_BODY, fontSize:12, color:"#B08AC4", textAlign:"center", marginBottom:10 }}>{notice}</p>}
        <div style={{ ...cardStyle }}>
          <StepBadge n={2} />
          <h2 style={{ fontFamily:F_HEAD, fontSize:18, color:"#5B6BA8", margin:"12px 0 4px" }}>本当は、こんな自分でいたかった</h2>
          <p style={{ fontFamily:F_BODY, fontSize:13.5, lineHeight:1.8, color:"#6E7A9E", margin:"0 0 6px" }}>
            「{chosenNeg}」の裏側には──
          </p>
          {desOptions.map((o, i) => (
            <button key={i} className="opt" style={{ ...optionBtn, animation:`fadeUp .45s ${i*0.12}s both ease-out` }} onClick={() => goStep3(o)}>{o.wish}</button>
          ))}
          <div style={{ display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap", marginTop:18 }}>
            <button className="btnG" style={btnGhost} onClick={() => goStep2(chosenNeg, true)}>🔁 別の候補を見る</button>
            <button className="btnG" style={btnGhost} onClick={() => setScreen("step1")}>← 痛みを選び直す</button>
          </div>
        </div>
      </div>
    );

    if(screen === "step3") return (
      <div>
        {notice && <p style={{ fontFamily:F_BODY, fontSize:12, color:"#B08AC4", textAlign:"center", marginBottom:10 }}>{notice}</p>}
        <div style={{ ...cardStyle }}>
          <StepBadge n={3} />
          <h2 style={{ fontFamily:F_HEAD, fontSize:18, color:"#5B6BA8", margin:"12px 0 4px" }}>その奥で、本当に欲しかったもの</h2>
          <p style={{ fontFamily:F_BODY, fontSize:13.5, lineHeight:1.8, color:"#6E7A9E", margin:"0 0 6px" }}>
            「{chosenDes ? chosenDes.vow : ""}という私」の核にあるのは──
          </p>
          {emoOptions.map((o, i) => (
            <button key={i} className="opt" style={{ ...optionBtn, animation:`fadeUp .45s ${i*0.12}s both ease-out` }} onClick={() => goReveal(o)}>
              <span style={{ fontWeight:700, color:"#5B6BA8" }}>{o.emotion}</span>
              <span style={{ display:"block", fontSize:12.5, color:"#8A96BC", marginTop:4 }}>{o.note}</span>
            </button>
          ))}
          <div style={{ display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap", marginTop:18 }}>
            <button className="btnG" style={btnGhost} onClick={() => goStep3(chosenDes, true)}>🔁 別の候補を見る</button>
            <button className="btnG" style={btnGhost} onClick={() => setScreen("step2")}>← なりたい自分を選び直す</button>
          </div>
        </div>
      </div>
    );

    if(screen === "reveal"){
      const emo = chosenEmo ? chosenEmo.emotion : "";
      const big = emo.length > 16;
      return (
        <div style={{ ...cardStyle, textAlign:"center", position:"relative", overflow:"hidden" }}>
          <div aria-hidden="true" style={{ position:"absolute", inset:0, pointerEvents:"none",
            background:"radial-gradient(circle at 20% 15%, rgba(190,220,255,.35), transparent 45%), radial-gradient(circle at 85% 80%, rgba(255,200,225,.35), transparent 45%)" }} />
          <Milly src={MILLY_WINK} size={140} style={{ margin:"4px auto 8px",
            animation:"pop .8s ease-out both, floaty 2.8s .8s ease-in-out infinite", position:"relative" }} />
          <p style={{ fontFamily:F_BODY, fontSize:14.5, lineHeight:2, color:"#6E7A9E",
            textWrap:"balance", margin:"0 0 4px", position:"relative" }}>
            『{chosenNeg}』が嫌で、
          </p>
          <p style={{ fontFamily:F_BODY, fontSize:14.5, lineHeight:2, color:"#6E7A9E",
            textWrap:"balance", margin:"0 0 14px", position:"relative" }}>
            {chosenDes ? chosenDes.vow : ""}という私でいたくて、
          </p>
          <p style={{ fontFamily:F_HEAD, lineHeight:1.5, letterSpacing:".03em", position:"relative",
            animation:"revealGlow 1.1s .3s both",
            fontSize: big ? "clamp(21px, 6vw, 32px)" : "clamp(27px, 8vw, 42px)",
            textWrap:"balance",
            background:RAINBOW, WebkitBackgroundClip:"text", backgroundClip:"text", color:"transparent",
            margin:"0 0 6px", padding:"0 4px" }}>
            {emo}
          </p>
          <p style={{ fontFamily:F_HEAD, fontSize:17, color:"#5B6BA8", margin:"0 0 8px", position:"relative" }}>
            が欲しかったんだ！
          </p>
          <p style={{ fontFamily:F_HAND, fontSize:13.5, lineHeight:1.9, color:"#8A96BC", margin:"0 0 20px", position:"relative" }}>
            {chosenEmo ? chosenEmo.note : ""}
          </p>
          <div style={{ display:"flex", flexDirection:"column", gap:10, alignItems:"center", position:"relative" }}>
            <button className="btnP" style={btnPrimary} onClick={saveWish} disabled={saved}>この願いを保存する</button>
            <button className="btnG" style={btnGhost} onClick={restart}>もう一度 はじめから</button>
          </div>
        </div>
      );
    }

    if(screen === "list"){
      const n = wishes.length;
      const unlocked = n >= 10;
      return (
        <div>
          {saved && (
            <div style={{ display:"flex", alignItems:"flex-end", gap:10, marginBottom:14 }}>
              <Milly src={MILLY_STD} size={64} style={{ animation:"floaty 3s ease-in-out infinite" }} />
              <div style={{ flex:1, background:"rgba(255,255,255,.9)", borderRadius:"18px 18px 18px 4px",
                padding:"11px 14px", fontFamily:F_HAND, fontSize:13.5, lineHeight:1.8, color:"#5B6BA8",
                boxShadow:"0 6px 16px rgba(150,170,220,.2)", animation:"fadeUp .5s both ease-out" }}>
                {millyLine(wishes.length)}
              </div>
            </div>
          )}
          <div style={{ ...cardStyle }}>
            <h2 style={{ fontFamily:F_HEAD, fontSize:19, color:"#5B6BA8", margin:"0 0 4px" }}>願い事リスト</h2>
            <p style={{ fontFamily:F_BODY, fontSize:13, color:"#6E7A9E", margin:"0 0 12px" }}>
              願いが10個そろうと「5次元オーダー」がひらきます。
            </p>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:16 }} aria-label={`願い ${n} / 10`}>
              {Array.from({length:10}).map((_, i) => (
                <span key={i} style={{ width:20, height:14, borderRadius:999,
                  background: i < n ? RAINBOW : "#E7EEFA",
                  boxShadow: i < n ? "0 2px 6px rgba(180,160,230,.4)" : "none" }} />
              ))}
              <span style={{ fontFamily:F_HEAD, fontSize:13, color:"#8A96BC", marginLeft:4 }}>{Math.min(n,10)} / 10</span>
            </div>
            {demoMode && (
              <div style={{ textAlign:"center", marginBottom:12 }}>
                <button className="btnG" style={{ ...btnGhost, fontSize:11, color:"#C49BD8" }} onClick={fillDemoWishes}>
                  🧪 テスト用：サンプルの願いを10個うめる
                </button>
              </div>
            )}
            {n === 0 && (
              <p style={{ fontFamily:F_HAND, fontSize:14, color:"#9AA6C8", textAlign:"center", padding:"18px 0" }}>
                まだ願いはありません。<br/>最初のひとつを、ミリィと見つけにいこう。
              </p>
            )}
            {wishes.map(w => (
              <div key={w.id} style={{ background:"linear-gradient(120deg,#F4F9FF,#FFF3F8)",
                border:"1.5px solid #E3ECFA", borderRadius:18, padding:"14px 16px", marginTop:12 }}>
                <p style={{ fontFamily:F_BODY, fontSize:13.5, lineHeight:1.9, color:"#4A5578", margin:0 }}>
                  {narrate(w)}
                </p>
                <div style={{ textAlign:"right", marginTop:6 }}>
                  <button onClick={() => deleteWish(w.id)}
                    style={{ fontFamily:F_BODY, fontSize:11, color:"#B0BBD8", background:"none",
                      border:"none", cursor:"pointer", textDecoration:"underline" }}>
                    削除
                  </button>
                </div>
              </div>
            ))}
            <div style={{ display:"flex", flexDirection:"column", gap:10, alignItems:"center", marginTop:20 }}>
              {unlocked && (
                <button className="btnP" style={btnPrimary} onClick={() => { setOrderDone(false); setScreen("order"); }}>
                  ✨ 5次元オーダーをひらく
                </button>
              )}
              {islands.length > 0 && (
                <button className="btnG" style={btnGhost} onClick={() => setScreen("kingdom")}>
                  ☁ ねがいの国へ（{islands.length}島）
                </button>
              )}
              <button className="btnG" style={btnGhost} onClick={restart}>あたらしい願いを見つける</button>
            </div>
          </div>
        </div>
      );
    }

    if(screen === "order"){
      const ten = wishes.slice(0, 10);
      return (
        <div style={{ ...cardStyle, textAlign:"center" }}>
          <div style={{ position:"relative", width:190, margin:"2px auto 8px" }}>
            <div aria-hidden="true" className="aura" />
            <Milly src={MILLY_SPARKLE} size={170}
              style={{ margin:"0 auto", position:"relative",
                animation:"arrive 1.2s ease-out both, floaty 2.6s 1.2s ease-in-out infinite",
                filter:"drop-shadow(0 0 18px rgba(255,220,150,.75))" }} />
            {orderDone && [...Array(8)].map((_, i) => (
              <span key={i} className="burst" style={{
                left:"50%", top:"50%",
                "--dx": Math.cos(i*Math.PI/4)*95 + "px",
                "--dy": Math.sin(i*Math.PI/4)*95 + "px",
                animationDelay: (i*0.06) + "s" }}>✦</span>
            ))}
          </div>
          <h2 style={{ fontFamily:F_HEAD, fontSize:20, margin:"0 0 6px",
            background:RAINBOW, WebkitBackgroundClip:"text", backgroundClip:"text", color:"transparent" }}>
            5次元オーダー
          </h2>
          <p style={{ fontFamily:F_HAND, fontSize:14, lineHeight:1.9, color:"#7A86B8", margin:"0 0 16px" }}>
            みつけた10の願いを、ねがいぐもに乗せて──<br/>ミリィが空のむこうへ届けます。
          </p>
          <div style={{ textAlign:"left" }}>
            {ten.map((w, i) => (
              <div key={w.id} style={{ background:"linear-gradient(120deg,#F4F9FF,#FFF3F8)",
                border:"1.5px solid #E3ECFA", borderRadius:18, padding:"13px 16px", marginTop:10,
                animation:`fadeUp .6s ${i*0.12}s both ease-out` }}>
                <span style={{ fontFamily:F_HEAD, fontSize:11, color:"#A9B4D6" }}>ねがい {i+1}</span>
                <p style={{ fontFamily:F_BODY, fontSize:13, lineHeight:1.9, color:"#4A5578", margin:"4px 0 0" }}>
                  {narrate(w)}
                </p>
              </div>
            ))}
          </div>
          {!orderDone ? (
            <div style={{ marginTop:20 }}>
              <button className="btnP" style={btnPrimary} onClick={() => setOrderDone(true)}>オーダーを唱える</button>
            </div>
          ) : (
            <div style={{ marginTop:20 }}>
              <p style={{ fontFamily:F_HEAD, fontSize:16, lineHeight:1.9, margin:"0 0 8px",
                background:RAINBOW, WebkitBackgroundClip:"text", backgroundClip:"text", color:"transparent" }}>
                オーダー、完了。
              </p>
              <p style={{ fontFamily:F_HAND, fontSize:13.5, lineHeight:1.9, color:"#7A86B8", margin:"0 0 14px" }}>
                手放された10の願いは、光になって──<br/>あなたの空に、あたらしい島を生みます。
              </p>
              <input
                value={islandName}
                onChange={e => setIslandName(e.target.value)}
                maxLength={12}
                placeholder={`島の名前をつけよう（例：はじまりの島）`}
                style={{ width:"100%", boxSizing:"border-box", fontFamily:F_BODY, fontSize:14,
                  padding:"12px 16px", borderRadius:14, border:"1.5px solid rgba(255,255,255,.8)",
                  background:"rgba(255,255,255,.6)", color:"#4A5578", outline:"none",
                  textAlign:"center", marginBottom:12 }}
              />
              <div style={{ display:"flex", flexDirection:"column", gap:10, alignItems:"center" }}>
                <button className="btnP" style={btnPrimary} onClick={makeIsland}>☁ この願いで、島をつくる</button>
                <button className="btnG" style={btnGhost} onClick={() => setScreen("list")}>リストに戻る</button>
              </div>
            </div>
          )}
          {!orderDone && (
            <div style={{ marginTop:10 }}>
              <button className="btnG" style={btnGhost} onClick={() => setScreen("list")}>← リストに戻る</button>
            </div>
          )}
        </div>
      );
    }

    if(screen === "kingdom"){
      const n = islands.length;
      return (
        <div style={{ ...cardStyle, textAlign:"center" }}>
          <MillyPuppet size={130} style={{ margin:"0 auto 4px" }} />
          <h2 style={{ fontFamily:F_HEAD, fontSize:21, margin:"0 0 4px",
            background:RAINBOW, backgroundSize:"200% 100%", WebkitBackgroundClip:"text",
            backgroundClip:"text", color:"transparent", animation:"hueSlide 7s linear infinite" }}>
            ねがいの国
          </h2>
          <p style={{ fontFamily:F_HAND, fontSize:13, lineHeight:1.9, color:"#7A86B8", margin:"0 0 6px" }}>
            5次元オーダーを重ねるたび、島がひとつ生まれます。<br/>ここは、あなたの願いでできた国。
          </p>
          <p style={{ fontFamily:F_BODY, fontSize:12, color:"#8A96BC", margin:"0 0 14px" }}>
            いま {n} つの島 ／ 3島で虹の橋、7島でふたつ目の月がかかります
          </p>
          {n >= 3 && (
            <div aria-hidden="true" style={{ height:56, margin:"0 0 6px", borderRadius:"999px 999px 0 0",
              background:"linear-gradient(180deg, transparent 40%, transparent), radial-gradient(ellipse at 50% 100%, transparent 55%, rgba(255,150,180,.5) 56% 63%, rgba(255,220,150,.5) 63% 70%, rgba(160,230,190,.5) 70% 77%, rgba(150,200,255,.55) 77% 84%, rgba(195,165,255,.5) 84% 91%, transparent 92%)" }} />
          )}
          {n >= 7 && (
            <p style={{ fontFamily:F_HAND, fontSize:12, color:"#B9A8E0", margin:"0 0 8px" }}>🌙 ふたつ目の月が、そっと昇りました</p>
          )}
          <div style={{ textAlign:"left" }}>
            {islands.map((is, i) => (
              <div key={is.id} style={{
                background:"linear-gradient(150deg, rgba(255,255,255,.6), rgba(255,255,255,.42)) padding-box, linear-gradient(120deg, rgba(255,235,170,.9), rgba(160,200,255,.8)) border-box",
                border:"1.5px solid transparent", borderRadius:24, padding:"14px 18px", marginTop:12,
                boxShadow:"0 10px 24px rgba(130,150,215,.25)",
                animation:`fadeUp .5s ${i*0.1}s both ease-out, islandFloat ${3 + (i%3)*0.6}s ${i*0.4}s ease-in-out infinite` }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:22 }}>☁️</span>
                  <span style={{ fontFamily:F_HEAD, fontSize:15, color:"#5B6BA8" }}>{is.name}</span>
                  <span style={{ fontFamily:F_BODY, fontSize:10.5, color:"#A9B4D6", marginLeft:"auto" }}>{is.date}</span>
                </div>
                <p style={{ fontFamily:F_HAND, fontSize:11.5, lineHeight:1.8, color:"#8A96BC", margin:"6px 0 0" }}>
                  この島に眠る願い：{(is.emos || []).slice(0,3).join("、")} …
                </p>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:10, alignItems:"center", marginTop:20 }}>
            <button className="btnP" style={btnPrimary} onClick={restart}>つぎの島へ──願いを見つける</button>
            <button className="btnG" style={btnGhost} onClick={() => { setSaved(false); setScreen("list"); }}>リストに戻る</button>
          </div>
        </div>
      );
    }

    return null;
  }

  return (
    <div ref={topRef} style={{ minHeight:"100vh", background:"transparent", padding:"0 16px 48px" }}>
      <style>{`
        @keyframes floaty { 0%,100%{ transform:translateY(0) rotate(-1.6deg) } 50%{ transform:translateY(-9px) rotate(1.6deg) } }
        @keyframes bounceDot { 0%,100%{ transform:translateY(0); opacity:.5 } 50%{ transform:translateY(-7px); opacity:1 } }
        @keyframes fadeUp { from{ opacity:0; transform:translateY(10px) } to{ opacity:1; transform:translateY(0) } }
        @keyframes drift { from{ transform:translateX(-200px) } to{ transform:translateX(calc(100vw + 220px)) } }
        @keyframes twinkleAnim { 0%,100%{ opacity:.15; transform:scale(.7) } 50%{ opacity:.9; transform:scale(1.15) } }
        @keyframes arrive { from{ opacity:0; transform:scale(.55) translateY(36px) } to{ opacity:1; transform:scale(1) translateY(0) } }
        @keyframes auraPulse { 0%,100%{ opacity:.5; transform:scale(.95) } 50%{ opacity:.9; transform:scale(1.08) } }
        @keyframes burstOut { from{ opacity:1; transform:translate(-50%,-50%) scale(.4) }
          to{ opacity:0; transform:translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))) scale(1.25) } }
        .cloud { position:absolute; left:-220px; background:#fff; border-radius:999px;
          filter:blur(1.5px); box-shadow:0 6px 16px rgba(160,180,225,.25);
          animation:drift linear infinite; }
        .cloud::before, .cloud::after { content:""; position:absolute; background:#fff; border-radius:50%; }
        .cloud::before { width:55%; height:170%; left:12%; top:-80%; }
        .cloud::after  { width:38%; height:125%; right:12%; top:-50%; }
        .twinkle { position:absolute; font-size:13px; color:#FFD9A0;
          text-shadow:0 0 8px rgba(255,200,120,.8); animation:twinkleAnim 3.2s ease-in-out infinite; }
        .rainbowArc { position:absolute; left:50%; top:-360px; width:720px; height:720px;
          transform:translateX(-50%); border-radius:50%; filter:blur(7px); opacity:.8;
          background:radial-gradient(circle,
            transparent 53%,
            rgba(255,150,180,.28) 54% 59%,
            rgba(255,200,140,.26) 59% 64%,
            rgba(255,240,170,.24) 64% 69%,
            rgba(165,230,190,.24) 69% 74%,
            rgba(150,200,255,.28) 74% 79%,
            rgba(195,165,255,.26) 79% 84%,
            transparent 85%); }
        .aura { position:absolute; inset:-24px; border-radius:50%;
          background:radial-gradient(circle, rgba(255,235,180,.55), rgba(255,180,220,.3) 55%, transparent 72%);
          animation:auraPulse 2.4s ease-in-out infinite; }
        .burst { position:absolute; font-size:20px; color:#FFC96B;
          text-shadow:0 0 10px rgba(255,200,120,.9);
          animation:burstOut 1.1s ease-out both; }
        .star { position:absolute; border-radius:50%; background:#fff;
          box-shadow:0 0 6px rgba(255,255,255,.95), 0 0 14px rgba(200,215,255,.6);
          animation:starTw 2.6s ease-in-out infinite; }
        @keyframes starTw { 0%,100%{ opacity:.25; transform:scale(.7) } 50%{ opacity:1; transform:scale(1.15) } }
        .aurora { position:absolute; left:-20%; top:-12%; width:140%; height:55%;
          border-radius:50%; filter:blur(42px); opacity:.55;
          background:linear-gradient(115deg, rgba(130,255,215,.35), rgba(150,185,255,.42),
            rgba(255,165,220,.38), rgba(185,255,205,.3));
          animation:auroraShift 9s ease-in-out infinite alternate; }
        @keyframes auroraShift { from{ transform:translateX(-5%) rotate(-3deg) } to{ transform:translateX(5%) rotate(3deg) } }
        .shooting { position:absolute; width:130px; height:2.5px; border-radius:999px;
          background:linear-gradient(90deg, rgba(255,255,255,0), #fff);
          transform:rotate(32deg); opacity:0; animation:shoot 5s ease-in infinite; }
        @keyframes shoot { 0%{ opacity:0; transform:rotate(32deg) translateX(0) }
          5%{ opacity:1 } 16%{ opacity:0; transform:rotate(32deg) translateX(48vw) }
          100%{ opacity:0; transform:rotate(32deg) translateX(48vw) } }
        @keyframes pop { 0%{ opacity:0; transform:scale(.4) rotate(-8deg) }
          60%{ opacity:1; transform:scale(1.08) rotate(3deg) } 100%{ transform:scale(1) rotate(0deg) } }
        @keyframes revealGlow { from{ opacity:0; filter:blur(10px); transform:scale(.92); letter-spacing:.18em }
          to{ opacity:1; filter:blur(0); transform:scale(1); letter-spacing:.03em } }
        @keyframes hueSlide { from{ background-position:0% 50% } to{ background-position:200% 50% } }
        @keyframes islandFloat { 0%,100%{ transform:translateY(0) } 50%{ transform:translateY(-7px) } }
        @keyframes hoverFloat { 0%,100%{ transform:translateY(0) rotate(-1.2deg) }
          50%{ transform:translateY(-16px) rotate(1.2deg) } }
        .hoverShadow { width:52%; height:13px; margin:6px auto 0; border-radius:50%;
          background:radial-gradient(ellipse, rgba(110,100,185,.38), rgba(110,100,185,0) 70%);
          filter:blur(4px); animation:shadowPulse 3.1s ease-in-out infinite; }
        @keyframes shadowPulse { 0%,100%{ transform:scaleX(1); opacity:.65 }
          50%{ transform:scaleX(.7); opacity:.28 } }
        @keyframes flapL { 0%,100%{ transform:rotate(0deg) } 50%{ transform:rotate(7deg) } }
        @keyframes flapR { 0%,100%{ transform:rotate(0deg) } 50%{ transform:rotate(-7deg) } }
        @keyframes breathe { 0%,100%{ transform:scale(1) } 50%{ transform:scale(1.014) } }
        @keyframes haloBob { 0%,100%{ transform:translateY(0); filter:drop-shadow(0 0 4px rgba(255,215,130,.55)) }
          50%{ transform:translateY(-4px); filter:drop-shadow(0 0 10px rgba(255,220,140,.95)) } }
        .millyGlow { position:absolute; inset:-10%; border-radius:50%;
          background:radial-gradient(circle, rgba(255,242,205,.55), rgba(195,175,255,.28) 55%, transparent 72%);
          filter:blur(12px); animation:auraPulse 3.6s ease-in-out infinite; }
        .moon { position:absolute; right:7%; top:8%; width:88px; height:88px; border-radius:50%;
          background:radial-gradient(circle at 38% 35%, #FFFDF2, #FFF0C6 55%, rgba(255,236,190,.3) 78%, transparent 84%);
          box-shadow:0 0 36px rgba(255,240,200,.75), 0 0 90px rgba(255,228,180,.4);
          animation:moonPulse 5s ease-in-out infinite; }
        @keyframes moonPulse { 0%,100%{ transform:scale(1) } 50%{ transform:scale(1.045) } }
        .mote { position:absolute; bottom:-12px; width:7px; height:7px; border-radius:50%;
          background:radial-gradient(circle, #FFF3D0 0%, #FFCE7E 55%, rgba(255,190,110,0) 78%);
          box-shadow:0 0 10px rgba(255,190,105,.95), 0 0 22px rgba(255,170,120,.55);
          animation:moteRise linear infinite; }
        @keyframes moteRise { 0%{ transform:translate(0,0) scale(.8); opacity:0 } 8%{ opacity:.95 }
          50%{ transform:translate(16px,-52vh) scale(1.1); opacity:.8 }
          92%{ opacity:.3 } 100%{ transform:translate(-10px,-104vh) scale(.9); opacity:0 } }
        .streak { position:absolute; top:-90px; width:2.5px; height:80px; border-radius:999px;
          background:linear-gradient(180deg, rgba(255,255,255,0), rgba(255,255,255,.85));
          animation:streakDown 1.7s linear infinite; }
        @keyframes streakDown { from{ transform:translateY(-90px); opacity:0 }
          18%{ opacity:.9 } to{ transform:translateY(420px); opacity:0 } }
        .btnP { transition:transform .16s ease, box-shadow .16s ease; }
        .btnP:hover { transform:translateY(-1.5px); }
        .btnP:active { transform:scale(.96); }
        .btnP::after { content:""; position:absolute; top:0; left:-70%; width:45%; height:100%;
          background:linear-gradient(100deg, transparent, rgba(255,255,255,.6), transparent);
          transform:skewX(-20deg); animation:shineSweep 3.4s ease-in-out infinite; }
        @keyframes shineSweep { 0%{ left:-70% } 55%{ left:140% } 100%{ left:140% } }
        .btnG { transition:transform .16s ease, background .16s ease; }
        .btnG:hover { transform:translateY(-1px); background:rgba(255,255,255,.75) !important; }
        .btnG:active { transform:scale(.96); }
        .opt { transition:transform .18s ease, box-shadow .18s ease; }
        .opt:hover { transform:translateY(-2.5px);
          box-shadow:0 12px 28px rgba(140,160,225,.32), inset 0 1px 0 rgba(255,255,255,.6); }
        .opt:active { transform:scale(.975); }
        @media (prefers-reduced-motion: reduce){
          * { animation:none !important; transition:none !important }
          .twinkle, .star { animation:twinkleAnim 3.4s ease-in-out infinite !important }
        }
        button:focus-visible { outline:3px solid #9DBBF2; outline-offset:2px }
        textarea:focus, input:focus { border-color:#A9C6F5 !important }
      `}</style>
      <DreamLayer phase={phase} />
      <MoteLayer />
      <div style={{ maxWidth:560, margin:"0 auto", position:"relative", zIndex:1 }}>
        {header}
        <div key={screen + (loading ? "-l" : "")} style={{ animation:"fadeUp .55s both ease-out" }}>
          {renderScreen()}
        </div>
        <p onClick={footerTap} style={{ textAlign:"center", fontFamily:F_HAND, fontSize:11, marginTop:28,
          color: phase >= 3 ? "rgba(255,255,255,.8)" : "#AEB9D8", cursor:"default", userSelect:"none" }}>
          ねがいぐも — 痛みの奥の、ほんとうの願いへ 🐬{demoMode ? " 🧪" : ""}
        </p>
      </div>
    </div>
  );
}
